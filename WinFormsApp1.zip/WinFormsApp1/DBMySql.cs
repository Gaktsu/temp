﻿using MySql.Data.MySqlClient;
using System;
using System.Data;
using System.Windows.Forms;

namespace WinFormsApp1
{
    public class DBMySql
    {
        //MySqlConnection mysql = new MySqlConnection($"Server={Config._server};Port = {3306};Uid={Config._id};Pwd={Config._pw};database={Config._database};");
        //MySqlDataAdapter? adpt; //생성자 앞 ? 는 null 허용을 의미
        //MySqlCommand? cmd;
        int port = 3306;
        string _connectionAddress = "";
        public DBMySql()
        {
            _connectionAddress = string.Format("Server={0};Port={1};Database={2};Uid={3};Pwd={4}", Config._server, port, Config._database, Config._id, Config._pw);
        }
        
        public string connection()
        {
            return _connectionAddress;
        }
        //public void Connection()
        //{
        //    try
        //    {
        //        mysql.Open();
        //    }
        //    catch (Exception e)
        //    {
        //        MessageBox.Show(e.ToString());
        //        throw;
        //    }
        //    mysql.Close();
        //}

        //public DataSet? SelectAll(string table)
        //{
        //    try
        //    {
        //        DataSet ds = new();

        //        string sql = $"SELECT * FROM {table}";
        //        adpt = new MySqlDataAdapter(sql, mysql);
        //        adpt.Fill(ds, table);
        //        if (ds.Tables.Count > 0)
        //        {
        //            return ds;
        //        }
        //        else
        //        {
        //            return null;
        //        }
        //    }
        //    catch (Exception e)
        //    {
        //        MessageBox.Show(e.ToString());
        //        throw;
        //    }
        //}

        //public DataSet? SelectDetail(string condition, string table, string where = "")
        //{
        //    try
        //    {
        //        DataSet ds = new();

        //        string sql = $"SELECT {condition} FROM {table} {where}";
        //        adpt = new MySqlDataAdapter(sql, mysql);
        //        adpt.Fill(ds, table);
        //        if (ds.Tables.Count > 0)
        //        {
        //            return ds;
        //        }
        //        else
        //        {
        //            return null;
        //        }
        //    }
        //    catch (Exception e)
        //    {
        //        MessageBox.Show(e.ToString());
        //        throw;
        //    }
        //}

        public void Insert(string table, string value)
        {
            try
            {
                using(MySqlConnection mysql = new MySqlConnection(_connectionAddress))
                {
                    mysql.Open();
                    string sql = $"INSERT INTO {table}(user_id, user_pw, name, phone, birth) VALUES ({value});";
                    // INSERT INTO member_table(name, phone) VALUES('{0}', '{1}');
                    //INSERT INTO user_info VALUES ('user1', 'j', 'ella', '1993/06/18', 'user1234', 1000000000)
                    MySqlCommand cmd = new MySqlCommand(sql, mysql);
                    //cmd.ExecuteNonQuery();
                    mysql.Close();
                }                 
            }
            catch (Exception e)
            {
                MessageBox.Show(e.ToString());
                throw;
            }
        }

        //public void Update(string table, string setvalue, string wherevalue = "")
        //{
        //    try
        //    {
        //        mysql.Open();
        //        string sql = $"UPDATE {table} SET {setvalue} {wherevalue}";
        //        //UPDATE user_info SET firt_name='lee' WHERE user_id='shotslove'
        //        cmd = new MySqlCommand(sql, mysql);
        //        cmd.ExecuteNonQuery();
        //        mysql.Close();
        //    }
        //    catch (Exception e)
        //    {
        //        MessageBox.Show(e.ToString());
        //        throw;
        //    }
        //}

        //public void DeleteAll(string table)
        //{
        //    try
        //    {
        //        mysql.Open();
        //        string sql = $"DELETE FROM {table}";
        //        //DELETE FROM user_info WHERE user_id='user1'
        //        cmd = new MySqlCommand(sql, mysql);
        //        cmd.ExecuteNonQuery();
        //        mysql.Close();
        //    }
        //    catch (Exception e)
        //    {
        //        MessageBox.Show(e.ToString());
        //        throw;
        //    }
        //}

        //public void DeleteDetail(string table, string wherecol, string wherevalue)
        //{
        //    try
        //    {
        //        mysql.Open();
        //        string sql = $"DELETE FROM {table} WHERE {wherecol}='{wherevalue}'";
        //        //DELETE FROM user_info WHERE user_id='user1'
        //        cmd = new MySqlCommand(sql, mysql);
        //        cmd.ExecuteNonQuery();
        //        mysql.Close();
        //    }
        //    catch (Exception e)
        //    {
        //        MessageBox.Show(e.ToString());
        //        throw;
        //    }
        //}
    }
}