﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace WinFormsApp1
{
    public partial class Form3 : Form //회원가입
    {
        DBMySql db = new();
        string _connectionAddress = "";
        public Form3()
        {
            InitializeComponent();
            _connectionAddress = db.connection();
        }

        private void btnSignup_Click(object sender, EventArgs e)//회원가입해서 DB에 넣기위한 함수
        {
            string value = $"'{txtID.Text}', '{txtPW.Text}', '{txtName.Text}', '{txtBirth.Text}', '{txtPhone.Text}'"; //적은 값들 value에 저장
            bool pw_v = isValidPassword();
            bool id_v = isValidID();
            bool ph_v = isValidnumber();
            bool bi_v = isValidbirth();
            bool pw2_v = isOverlapPassword();
            if (!pw_v || !id_v || !ph_v || !bi_v || !pw2_v) //아이디가 중복이다 또는 비번이 형식에 맞지 않다 (만약 pw_v가 true면 --> !pw_v == false 이다)
            {
                if (!pw_v) MessageBox.Show("영어, 숫자, 특수기호를 포함새서 4자리 이상 32자리 이하로 설정해주십시요");
                if(!id_v) MessageBox.Show("이미 존재하는 아이디입니다");
                if (!ph_v) MessageBox.Show("11자리 또는 - 를 붙여서 설정해주십시요");
                if (!bi_v) MessageBox.Show("존재하지 않는 생일이거나 6자리가 아닙니다");
                if (!pw2_v) MessageBox.Show("비밀번호가 일치하지 않습니다");
            }

            else// 중복이 아니다
            {
                using (MySqlConnection mysql = new MySqlConnection(_connectionAddress))// DB에 접속
                {
                    mysql.Open();
                    string insertQuery = string.Format($"INSERT INTO member_table(user_id, user_pw, name, phone, birth) VALUES({value});");// DB에 값 넣기
                    MySqlCommand command = new MySqlCommand(insertQuery, mysql);
                    if (command.ExecuteNonQuery() != 1) MessageBox.Show("Failed to insert data.");
                }
                MessageBox.Show("회원가입을 완료했습니다. 등록한 아이디로 로그인 해주세요.");
                this.Close();// Form3 닫기
            }
            
        }

        private bool isValidID()// ID 중복인지 확인
        {
            using (MySqlConnection mysql = new MySqlConnection(_connectionAddress))
            {
                mysql.Open();
                string selectQuery = string.Format("SELECT * FROM member_table");
                MySqlCommand command = new MySqlCommand(selectQuery, mysql);
                MySqlDataReader table = command.ExecuteReader();
                while (table.Read())// 하나하나 읽기
                {
                    if (txtID.Text == table["user_id"].ToString()) // 중복이라면
                    {
                        return false;// 회원가입 안시켜줌
                    }
                }
                table.Close();//열었던거 닫기
                return true;// 중복되지 않음
            }
        }

        public bool isValidPassword()
        {
            //영문, 숫자, 특수문자 포함 4-32자리
            Regex regex = new Regex(@"^(?=.*?[A-Za-z])(?=.*?\d)(?=.*?[~`!@#$%\^&*()-+=.]).{4,32}$"); //
            Match match = regex.Match(txtPW.Text);
            return match.Success;
        }

        public bool isOverlapPassword()
        {
            if (txtPW.Text == txtPW2.Text) return true;
            else return false;
        }

        public bool isValidnumber()
        {
            //11문자 ( - 이거 써도 되고 안써도 되고)
            Regex regex = new Regex(@"^\d{3}\w?[-]\d{4}?\w?[-]\d{4}$"); //
            Match match = regex.Match(txtPhone.Text);
            return match.Success;
        }

        public bool isValidbirth()
        {
            //020228 처럼 6자리로
            Regex regex = new Regex(@"^([0-9]{2}(0[1-9]|1[0-2])(0[1-9]|[1,2][0-9]|3[0,1]))$"); //
            Match match = regex.Match(txtBirth.Text);
            return match.Success;
        }
    }
}
