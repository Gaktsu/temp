﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using System.Data;

namespace WinFormsApp1
{
    enum eTName : int { _user }

    internal class Config
    {
        public static string _server = "localhost";
        public static string _id = "root";
        public static string _pw = "root";
        public static string _database = "sample";
        public static string[] Tables = { "member_table" };
        public static DataSet user_ds = null;
    }
}
