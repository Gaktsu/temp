﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;

namespace WinFormsApp1
{
    public partial class Form2 : Form //로그인
    {
        DBMySql db = new();
        string _connectionAddress = "";

        public Form2()
        {
            InitializeComponent();
            _connectionAddress = db.connection();
        }

        private void btnSignup_Click(object sender, EventArgs e) //회원가입 클릭시
        {
            Form3 f3 = new();
            f3.Show();
        }

        private void btnLogin_Click(object sender, EventArgs e) //로그인 클릭시
        {
            using (MySqlConnection mysql = new MySqlConnection(_connectionAddress))//server, port, uid, id, pw 들어있는거로 서버 접속
            {
                mysql.Open();// mysql 접속
                string selectQuery = string.Format("SELECT * FROM member_table");// 조회
                MySqlCommand command = new MySqlCommand(selectQuery, mysql);
                MySqlDataReader table = command.ExecuteReader();
                while (table.Read())// 하나하나 읽기
                {
                    if (txtPW.Text == table["user_pw"].ToString() && txtID.Text == table["user_id"].ToString())// 작성한 id/pw가 DB에 있으면
                    {
                        MessageBox.Show("안녕하세요 " + table["name"] + "님");
                        return; // 함수 탈출
                    }
                }
                table.Close();
                //그렇지 않으면
                MessageBox.Show("아이디 또는 비밀번호가 일치하지 않습니다.");
            }     
        }

        private void btnCheck_Click(object sender, EventArgs e)
        {

            // ID/PW 찾는 폼 생성해야하는 듯
        }
    }
}
