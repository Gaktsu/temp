using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using System.Runtime.InteropServices;

namespace WinFormsApp1
{
    public partial class Form1 : Form // ��ȸ�����θ� ���°� ������
    {
        DBMySql db = new();
        string _connectionAddress = "";

        public Form1()
        {
            InitializeComponent();
            _connectionAddress = db.connection();
            Form2 f2 = new Form2();
            f2.Show();
        }

        //listview ��� �뵵
        private void selectTable()
        {
            try
            {
                using (MySqlConnection mysql = new MySqlConnection(_connectionAddress))
                {
                    mysql.Open();
                    string selectQuery = string.Format("SELECT * FROM member_table");
                    MySqlCommand command = new MySqlCommand(selectQuery, mysql);
                    MySqlDataReader table = command.ExecuteReader();
                    listView1.Items.Clear();

                    while (table.Read())
                    {
                        ListViewItem item = new ListViewItem();
                        item.Text = table["id"].ToString();
                        item.SubItems.Add(table["user_id"].ToString());
                        item.SubItems.Add(table["user_pw"].ToString());
                        item.SubItems.Add(table["name"].ToString());
                        item.SubItems.Add(table["phone"].ToString());
                        item.SubItems.Add(table["birth"].ToString());
                        listView1.Items.Add(item);
                    }
                    table.Close();
                }
            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message);
            }
        }

        //Listview
        //private void button2_Click(object sender, EventArgs e)
        //{
        //    try
        //    {
        //        using (MySqlConnection mysql = new MySqlConnection(_connectionAddress))
        //        {
        //            mysql.Open();
        //            string insertQuery = string.Format("INSERT INTO member_table(name,phone) VALUES('{0}','{1}');", textBox1.Text, textBox2.Text);
        //            MySqlCommand command = new MySqlCommand(insertQuery, mysql);
        //            if (command.ExecuteNonQuery() != 1) MessageBox.Show("Failed to insert data.");
        //            textBox1.Text = "";
        //            textBox2.Text = "";
        //            selectTable();
        //        }
        //    }
        //    catch (Exception exc)
        //    {
        //        MessageBox.Show(exc.Message);
        //    }
        //}

        ////Listview
        //private void listView1_SelecedIndewChanged(object sender, EventArgs e)
        //{
        //    ListView? listView = sender as ListView;
        //    int index = listView.FocusedItem.Index;
        //    if (listView.SelectedItems.Count > 0)
        //    {
        //        textBox1.Text = listView.Items[index].SubItems[1].Text;
        //        textBox2.Text = listView.Items[index].SubItems[2].Text;
        //    }
        //}

        ////Listview
        //private void button3_Click(object sender, EventArgs e)
        //{
        //    try
        //    {
        //        using (MySqlConnection mysql = new MySqlConnection(_connectionAddress))
        //        {
        //            mysql.Open();
        //            int pos = listView1.SelectedItems[0].Index;
        //            int index = Convert.ToInt32(listView1.Items[pos].Text);

        //            string updateQuery = string.Format("UPDATE member_table SET name='{1}',phone='{2}' WHERE id={0};", index, textBox1.Text, textBox2.Text);
        //            MySqlCommand command = new MySqlCommand(updateQuery, mysql);
        //            if (command.ExecuteNonQuery() != 1) MessageBox.Show("Failed to update data.");
        //            textBox1.Text = "";
        //            textBox2.Text = "";
        //            selectTable();
        //        }
        //    }
        //    catch (Exception exc)
        //    {
        //        MessageBox.Show(exc.Message);
        //    }
        //}
        
        ////Listview
        //private void button5_Click(object sender, EventArgs e)
        //{
        //    try
        //    {
        //        using (MySqlConnection mysql = new MySqlConnection(_connectionAddress))
        //        {
        //            mysql.Open();
        //            int pos = listView1.SelectedItems[0].Index;
        //            int index = Convert.ToInt32(listView1.Items[pos].Text);

        //            string deleteQuery = string.Format("DELETE FROM member_table WHERE id={0};", index);
        //            MySqlCommand command = new MySqlCommand(deleteQuery, mysql);
        //            if (command.ExecuteNonQuery() != 1) MessageBox.Show("Failed to delete data.");
        //            textBox1.Text = "";
        //            textBox2.Text = "";
        //            selectTable();
        //        }
        //    }
        //    catch (Exception exc)
        //    {
        //        MessageBox.Show(exc.Message);
        //    }
        //}

        //Listview
        private void button4_Click(object sender, EventArgs e)
        {
            selectTable();
        }

        //Reset
        private void button1_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox2.Text = "";
        }
    }
}